import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'

import AppLayout from './components/AppLayout'
import DetailLayout from './components/DetailLayout'

import Splash from './pages/Splash'
import Login from './pages/Login'
import Register from './pages/Register'
import ForgotPassword from './pages/ForgotPassword'

import Home from './pages/Home'
import News from './pages/News'
import NewsDetail from './pages/NewsDetail'
import Events from './pages/Events'
import EventDetail from './pages/EventDetail'
import Guide from './pages/Guide'
import BusinessDetail from './pages/BusinessDetail'
import Jobs from './pages/Jobs'
import JobDetail from './pages/JobDetail'
import PublicUtility from './pages/PublicUtility'
import Classifieds from './pages/Classifieds'
import ClassifiedDetail from './pages/ClassifiedDetail'
import Profile from './pages/Profile'
import Favorites from './pages/Favorites'
import Settings from './pages/Settings'
import StaticPage from './pages/StaticPage'

export default function App() {
  return (
    <Routes>
      {/* Fluxo inicial */}
      <Route path="/" element={<Splash />} />
      <Route path="/login" element={<Login />} />
      <Route path="/criar-conta" element={<Register />} />
      <Route path="/esqueci-senha" element={<ForgotPassword />} />

      {/* Telas principais com header + menu inferior */}
      <Route element={<AppLayout />}>
        <Route path="/home" element={<Home />} />
        <Route path="/noticias" element={<News />} />
        <Route path="/eventos" element={<Events />} />
        <Route path="/guia" element={<Guide />} />
        <Route path="/empregos" element={<Jobs />} />
        <Route path="/classificados" element={<Classifieds />} />
        <Route path="/utilidade-publica" element={<PublicUtility />} />
        <Route path="/favoritos" element={<Favorites />} />
        <Route path="/perfil" element={<Profile />} />
        <Route path="/configuracoes" element={<Settings />} />
        <Route path="/sobre" element={<StaticPage />} />
        <Route path="/privacidade" element={<StaticPage />} />
        <Route path="/termos" element={<StaticPage />} />
      </Route>

      {/* Telas de detalhe com header de voltar */}
      <Route element={<DetailLayout />}>
        <Route path="/noticias/:id" element={<NewsDetail />} />
        <Route path="/eventos/:id" element={<EventDetail />} />
        <Route path="/guia/:id" element={<BusinessDetail />} />
        <Route path="/empregos/:id" element={<JobDetail />} />
        <Route path="/classificados/:id" element={<ClassifiedDetail />} />
      </Route>

      <Route path="*" element={<Navigate to="/home" replace />} />
    </Routes>
  )
}
