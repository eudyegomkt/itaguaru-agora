import React from 'react'
import { NavLink } from 'react-router-dom'
import { FiX, FiFileText, FiCalendar, FiBriefcase, FiTag, FiGrid, FiPhoneCall, FiHeart, FiSettings, FiInfo } from 'react-icons/fi'
import logo from '../assets/logo.png'
import { useApp } from '../context/AppContext'

const links = [
  { to: '/noticias', label: 'Notícias', icon: FiFileText },
  { to: '/eventos', label: 'Eventos', icon: FiCalendar },
  { to: '/empregos', label: 'Empregos', icon: FiBriefcase },
  { to: '/classificados', label: 'Classificados', icon: FiTag },
  { to: '/guia', label: 'Guia Comercial', icon: FiGrid },
  { to: '/utilidade-publica', label: 'Utilidade Pública', icon: FiPhoneCall },
  { to: '/favoritos', label: 'Favoritos', icon: FiHeart },
  { to: '/configuracoes', label: 'Configurações', icon: FiSettings },
  { to: '/sobre', label: 'Sobre', icon: FiInfo }
]

export default function Drawer({ open, onClose }) {
  const { user } = useApp()

  return (
    <>
      <div
        className={`fixed inset-0 z-40 bg-navy-900/50 transition-opacity duration-300 ${open ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />
      <aside
        className={`fixed top-0 left-0 z-50 h-full w-[78%] max-w-[320px] bg-white shadow-2xl transition-transform duration-300 ease-out ${
          open ? 'translate-x-0' : '-translate-x-full'
        } flex flex-col`}
      >
        <div className="flex items-center justify-between px-5 pt-6 pb-4 border-b border-navy-100">
          <img src={logo} alt="Itaguaru Agora" className="h-8 w-auto object-contain" />
          <button onClick={onClose} className="p-1.5 rounded-full hover:bg-navy-50">
            <FiX size={20} className="text-navy-700" />
          </button>
        </div>

        <div className="px-5 py-4 border-b border-navy-100">
          <p className="text-sm text-navy-500">Olá,</p>
          <p className="font-display font-bold text-navy-900 text-lg truncate">{user?.nome || 'Visitante'}</p>
        </div>

        <nav className="flex-1 overflow-y-auto py-2">
          {links.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              onClick={onClose}
              className={({ isActive }) =>
                `flex items-center gap-3 px-5 py-3.5 text-[15px] font-medium transition-colors ${
                  isActive ? 'text-brick-500 bg-brick-50' : 'text-navy-700 hover:bg-navy-50'
                }`
              }
            >
              <Icon size={19} />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="px-5 py-4 border-t border-navy-100">
          <p className="text-xs text-navy-400">Itaguaru Agora · v1.0.0</p>
        </div>
      </aside>
    </>
  )
}
