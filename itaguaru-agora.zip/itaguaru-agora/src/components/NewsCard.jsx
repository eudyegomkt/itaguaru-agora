import React from 'react'
import { Link } from 'react-router-dom'
import { FiClock } from 'react-icons/fi'

function formatDate(iso) {
  const d = new Date(iso + 'T00:00:00')
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })
}

export function NewsCardHorizontal({ news }) {
  return (
    <Link to={`/noticias/${news.id}`} className="flex gap-3 rounded-2xl bg-white p-2.5 shadow-card active:scale-[0.98] transition-transform">
      <img src={news.imagem} alt={news.titulo} className="h-20 w-20 shrink-0 rounded-xl object-cover" />
      <div className="flex-1 min-w-0 py-0.5">
        <span className="inline-block text-[10px] font-bold uppercase tracking-wide text-brick-500 mb-1">{news.categoria}</span>
        <p className="font-display font-semibold text-navy-900 text-sm leading-snug line-clamp-2">{news.titulo}</p>
        <div className="flex items-center gap-1 mt-1.5 text-navy-400 text-[11px]">
          <FiClock size={11} />
          <span>{formatDate(news.data)}</span>
        </div>
      </div>
    </Link>
  )
}

export function NewsCardFeatured({ news }) {
  return (
    <Link to={`/noticias/${news.id}`} className="relative block shrink-0 w-[78%] rounded-2xl overflow-hidden shadow-card active:scale-[0.98] transition-transform">
      <img src={news.imagem} alt={news.titulo} className="h-44 w-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-t from-navy-900/90 via-navy-900/20 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 p-3.5">
        <span className="inline-block text-[10px] font-bold uppercase tracking-wide text-white bg-brick-500 px-2 py-0.5 rounded-full mb-1.5">
          {news.categoria}
        </span>
        <p className="font-display font-bold text-white text-[15px] leading-snug line-clamp-2">{news.titulo}</p>
      </div>
    </Link>
  )
}

export default function NewsCard({ news }) {
  return (
    <Link to={`/noticias/${news.id}`} className="block rounded-2xl overflow-hidden bg-white shadow-card active:scale-[0.98] transition-transform">
      <img src={news.imagem} alt={news.titulo} className="h-36 w-full object-cover" />
      <div className="p-3.5">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[10px] font-bold uppercase tracking-wide text-brick-500">{news.categoria}</span>
          <span className="text-[11px] text-navy-400">{formatDate(news.data)}</span>
        </div>
        <p className="font-display font-semibold text-navy-900 text-[15px] leading-snug line-clamp-2 mb-1">{news.titulo}</p>
        <p className="text-[12.5px] text-navy-500 line-clamp-2">{news.resumo}</p>
      </div>
    </Link>
  )
}
