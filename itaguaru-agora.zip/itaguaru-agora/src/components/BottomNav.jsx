import React from 'react'
import { NavLink } from 'react-router-dom'
import { FiHome, FiFileText, FiCalendar, FiGrid, FiUser } from 'react-icons/fi'

const items = [
  { to: '/home', label: 'Home', icon: FiHome },
  { to: '/noticias', label: 'Notícias', icon: FiFileText },
  { to: '/eventos', label: 'Eventos', icon: FiCalendar },
  { to: '/guia', label: 'Guia', icon: FiGrid },
  { to: '/perfil', label: 'Perfil', icon: FiUser }
]

export default function BottomNav() {
  return (
    <nav className="sticky bottom-0 z-30 bg-white/95 backdrop-blur-md border-t border-navy-100 shadow-nav safe-bottom">
      <div className="flex items-stretch justify-between px-2">
        {items.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex flex-1 flex-col items-center justify-center gap-1 py-2.5 text-[11px] font-medium transition-colors ${
                isActive ? 'text-brick-500' : 'text-navy-400'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <Icon size={20} strokeWidth={isActive ? 2.4 : 1.8} />
                <span>{label}</span>
                {isActive && <span className="absolute -mt-[26px] h-1 w-1 rounded-full bg-brick-500" />}
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  )
}
