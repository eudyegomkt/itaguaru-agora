import React from 'react'
import { Link } from 'react-router-dom'
import { FiMapPin } from 'react-icons/fi'

function formatDate(iso) {
  const d = new Date(iso + 'T00:00:00')
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })
}

export default function EventCard({ event, compact }) {
  if (compact) {
    return (
      <Link to={`/eventos/${event.id}`} className="flex gap-3 rounded-2xl bg-white p-2.5 shadow-card active:scale-[0.98] transition-transform">
        <div className="flex h-16 w-16 shrink-0 flex-col items-center justify-center rounded-xl bg-navy-800 text-white">
          <span className="text-lg font-display font-bold leading-none">{formatDate(event.data).split(' ')[0]}</span>
          <span className="text-[10px] uppercase mt-0.5">{formatDate(event.data).split(' ')[1]}</span>
        </div>
        <div className="flex-1 min-w-0 py-0.5">
          <p className="font-display font-semibold text-navy-900 text-sm leading-snug line-clamp-1">{event.titulo}</p>
          <div className="flex items-center gap-1 mt-1 text-navy-400 text-[11px]">
            <FiMapPin size={11} />
            <span className="truncate">{event.local}</span>
          </div>
        </div>
      </Link>
    )
  }
  return (
    <Link to={`/eventos/${event.id}`} className="block rounded-2xl overflow-hidden bg-white shadow-card active:scale-[0.98] transition-transform">
      <div className="relative">
        <img src={event.imagem} alt={event.titulo} className="h-36 w-full object-cover" />
        <div className="absolute top-2.5 left-2.5 bg-white rounded-lg px-2.5 py-1 text-center shadow">
          <p className="text-[15px] font-display font-bold text-navy-900 leading-none">{formatDate(event.data).split(' ')[0]}</p>
          <p className="text-[9px] uppercase text-brick-500 font-bold">{formatDate(event.data).split(' ')[1]}</p>
        </div>
      </div>
      <div className="p-3.5">
        <p className="font-display font-semibold text-navy-900 text-[15px] leading-snug line-clamp-2 mb-1">{event.titulo}</p>
        <div className="flex items-center gap-1 text-navy-500 text-xs">
          <FiMapPin size={12} />
          <span className="truncate">{event.local}</span>
        </div>
      </div>
    </Link>
  )
}
