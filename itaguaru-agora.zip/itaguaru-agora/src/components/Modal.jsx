import React from 'react'
import { FiX } from 'react-icons/fi'

export default function Modal({ open, onClose, title, children }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-navy-900/50 animate-fadeIn" onClick={onClose} />
      <div className="relative w-full max-w-[420px] bg-white rounded-t-3xl sm:rounded-3xl p-5 animate-slideUp shadow-2xl">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display font-bold text-navy-900 text-lg">{title}</h3>
          <button onClick={onClose} className="p-1.5 rounded-full hover:bg-navy-50">
            <FiX size={19} className="text-navy-600" />
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}
