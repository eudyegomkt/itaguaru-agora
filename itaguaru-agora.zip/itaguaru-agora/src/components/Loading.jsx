import React from 'react'

export function CardSkeleton() {
  return (
    <div className="rounded-2xl overflow-hidden bg-white shadow-card animate-pulse">
      <div className="h-36 skeleton animate-shimmer" />
      <div className="p-3.5 space-y-2">
        <div className="h-3 w-16 rounded-full skeleton animate-shimmer" />
        <div className="h-4 w-full rounded skeleton animate-shimmer" />
        <div className="h-4 w-2/3 rounded skeleton animate-shimmer" />
      </div>
    </div>
  )
}

export function ListSkeleton({ count = 4 }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="flex gap-3 rounded-2xl bg-white p-3 shadow-card animate-pulse">
          <div className="h-20 w-20 shrink-0 rounded-xl skeleton animate-shimmer" />
          <div className="flex-1 space-y-2 py-1">
            <div className="h-3 w-14 rounded-full skeleton animate-shimmer" />
            <div className="h-4 w-full rounded skeleton animate-shimmer" />
            <div className="h-3 w-1/2 rounded skeleton animate-shimmer" />
          </div>
        </div>
      ))}
    </div>
  )
}

export default function Loading({ label = 'Carregando…' }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 gap-3">
      <div className="h-9 w-9 rounded-full border-[3px] border-navy-100 border-t-brick-500 animate-spin" />
      <p className="text-sm text-navy-400">{label}</p>
    </div>
  )
}
