import React from 'react'
import { FiCloud } from 'react-icons/fi'

export default function WeatherWidget({ weather }) {
  if (!weather) return null
  return (
    <div className="flex items-center justify-between rounded-2xl bg-gradient-to-br from-navy-800 to-navy-900 text-white px-4 py-3.5 shadow-card">
      <div>
        <p className="text-xs text-navy-200">{weather.cidade}</p>
        <p className="font-display font-bold text-2xl leading-tight">{weather.temperatura}°C</p>
        <p className="text-xs text-navy-200">{weather.condicao}</p>
      </div>
      <div className="flex flex-col items-end gap-1.5">
        <FiCloud size={26} className="text-navy-100" />
        <p className="text-[11px] text-navy-300">
          Mín {weather.minima}° · Máx {weather.maxima}°
        </p>
      </div>
    </div>
  )
}
