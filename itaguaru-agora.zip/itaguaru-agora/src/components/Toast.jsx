import React from 'react'
import { FiCheckCircle, FiInfo, FiAlertCircle } from 'react-icons/fi'
import { useApp } from '../context/AppContext'

const styles = {
  success: { bg: 'bg-navy-800', icon: FiCheckCircle },
  info: { bg: 'bg-navy-800', icon: FiInfo },
  error: { bg: 'bg-brick-600', icon: FiAlertCircle }
}

export default function Toast() {
  const { toast } = useApp()
  if (!toast) return null
  const { bg, icon: Icon } = styles[toast.type] || styles.info

  return (
    <div className="fixed left-1/2 bottom-24 z-[60] -translate-x-1/2 w-[88%] max-w-[380px] animate-slideUp">
      <div className={`${bg} text-white rounded-xl px-4 py-3 shadow-2xl flex items-center gap-2.5`}>
        <Icon size={18} className="shrink-0" />
        <p className="text-sm font-medium">{toast.message}</p>
      </div>
    </div>
  )
}
