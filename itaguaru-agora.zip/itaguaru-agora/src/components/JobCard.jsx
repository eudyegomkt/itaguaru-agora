import React from 'react'
import { Link } from 'react-router-dom'
import { FiMapPin, FiBriefcase } from 'react-icons/fi'

export default function JobCard({ job }) {
  return (
    <Link to={`/empregos/${job.id}`} className="block rounded-2xl bg-white p-3.5 shadow-card active:scale-[0.98] transition-transform">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="font-display font-semibold text-navy-900 text-sm truncate">{job.cargo}</p>
          <p className="text-xs text-navy-500 mt-0.5">{job.empresa}</p>
        </div>
        <span className="shrink-0 text-[10px] font-bold uppercase bg-navy-50 text-navy-700 px-2 py-1 rounded-full">{job.tipo}</span>
      </div>
      <div className="flex items-center gap-3 mt-2.5 text-[11px] text-navy-400">
        <span className="flex items-center gap-1">
          <FiMapPin size={11} /> {job.cidade}
        </span>
        <span className="flex items-center gap-1">
          <FiBriefcase size={11} /> {job.salario || 'A combinar'}
        </span>
      </div>
    </Link>
  )
}
