import React from 'react'

export default function CategoryFilter({ categories, active, onChange, includeAll = true }) {
  const items = includeAll ? ['Todas', ...categories] : categories
  return (
    <div className="flex gap-2 overflow-x-auto no-scrollbar px-4 py-1 -mx-4">
      {items.map((cat) => {
        const isActive = active === cat || (active === null && cat === 'Todas')
        return (
          <button
            key={cat}
            onClick={() => onChange(cat === 'Todas' ? null : cat)}
            className={`shrink-0 rounded-full px-4 py-1.5 text-[13px] font-medium transition-all border ${
              isActive
                ? 'bg-navy-800 text-white border-navy-800'
                : 'bg-white text-navy-600 border-navy-100 hover:border-navy-300'
            }`}
          >
            {cat}
          </button>
        )
      })}
    </div>
  )
}
