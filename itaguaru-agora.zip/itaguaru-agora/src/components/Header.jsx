import React from 'react'
import { FiMenu, FiArrowLeft, FiBell } from 'react-icons/fi'
import { useNavigate } from 'react-router-dom'
import logo from '../assets/logo.png'

export default function Header({ title, showLogo, showBack, onMenuClick, transparent, right }) {
  const navigate = useNavigate()

  return (
    <header
      className={`sticky top-0 z-30 flex items-center justify-between px-4 py-3 backdrop-blur-md ${
        transparent ? 'bg-transparent' : 'bg-white/90 border-b border-navy-100'
      }`}
    >
      <div className="flex items-center gap-3 min-w-0">
        {showBack ? (
          <button onClick={() => navigate(-1)} className="p-1.5 -ml-1.5 rounded-full hover:bg-navy-50 active:scale-90 transition">
            <FiArrowLeft size={20} className="text-navy-800" />
          </button>
        ) : (
          <button onClick={onMenuClick} className="p-1.5 -ml-1.5 rounded-full hover:bg-navy-50 active:scale-90 transition">
            <FiMenu size={20} className="text-navy-800" />
          </button>
        )}
        {showLogo ? (
          <img src={logo} alt="Itaguaru Agora" className="h-7 w-auto object-contain" />
        ) : (
          <h1 className="font-display font-bold text-navy-900 text-[17px] truncate">{title}</h1>
        )}
      </div>
      <div className="flex items-center gap-1">
        {right}
        <button className="p-2 rounded-full hover:bg-navy-50 active:scale-90 transition relative">
          <FiBell size={19} className="text-navy-700" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-brick-500" />
        </button>
      </div>
    </header>
  )
}
