import React from 'react'

const variants = {
  primary: 'bg-navy-800 text-white hover:bg-navy-700 active:bg-navy-900',
  accent: 'bg-brick-500 text-white hover:bg-brick-600 active:bg-brick-700',
  outline: 'bg-transparent text-navy-800 border border-navy-200 hover:bg-navy-50',
  ghost: 'bg-transparent text-navy-700 hover:bg-navy-50',
  white: 'bg-white text-navy-800 hover:bg-navy-50 shadow-card'
}

export default function Button({ children, variant = 'primary', className = '', icon: Icon, iconPosition = 'left', full, ...props }) {
  return (
    <button
      className={`inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition-all duration-200 active:scale-[0.97] disabled:opacity-50 disabled:pointer-events-none ${variants[variant]} ${full ? 'w-full' : ''} ${className}`}
      {...props}
    >
      {Icon && iconPosition === 'left' && <Icon size={17} />}
      {children}
      {Icon && iconPosition === 'right' && <Icon size={17} />}
    </button>
  )
}
