import React from 'react'
import { FiInbox } from 'react-icons/fi'

export default function EmptyState({ icon: Icon = FiInbox, title = 'Nada por aqui ainda', subtitle, action }) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-16 px-6 animate-fadeIn">
      <div className="h-16 w-16 rounded-2xl bg-navy-50 flex items-center justify-center mb-4">
        <Icon size={28} className="text-navy-300" />
      </div>
      <p className="font-display font-semibold text-navy-800">{title}</p>
      {subtitle && <p className="text-sm text-navy-400 mt-1 max-w-[240px]">{subtitle}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  )
}
