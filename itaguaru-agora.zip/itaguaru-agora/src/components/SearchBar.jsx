import React from 'react'
import { FiSearch } from 'react-icons/fi'

export default function SearchBar({ value, onChange, placeholder = 'Pesquisar em Itaguaru Agora' }) {
  return (
    <div className="flex items-center gap-2.5 bg-white rounded-2xl px-4 py-3 shadow-card border border-navy-100/60">
      <FiSearch size={18} className="text-navy-400 shrink-0" />
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="flex-1 bg-transparent text-sm text-navy-800 placeholder:text-navy-400 outline-none"
      />
    </div>
  )
}
