import React, { useState } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import Header from './Header'
import BottomNav from './BottomNav'
import Drawer from './Drawer'
import Toast from './Toast'

const titles = {
  '/home': null,
  '/noticias': 'Notícias',
  '/eventos': 'Eventos',
  '/guia': 'Guia Comercial',
  '/perfil': 'Perfil',
  '/empregos': 'Empregos',
  '/classificados': 'Classificados',
  '/utilidade-publica': 'Utilidade Pública',
  '/favoritos': 'Favoritos',
  '/configuracoes': 'Configurações',
  '/sobre': 'Sobre'
}

export default function AppLayout() {
  const [drawerOpen, setDrawerOpen] = useState(false)
  const location = useLocation()
  const showLogo = location.pathname === '/home'
  const title = titles[location.pathname] ?? ''

  return (
    <div className="app-shell flex flex-col">
      <Header title={title} showLogo={showLogo} onMenuClick={() => setDrawerOpen(true)} />
      <Drawer open={drawerOpen} onClose={() => setDrawerOpen(false)} />
      <main className="flex-1 overflow-y-auto no-scrollbar pb-4">
        <div key={location.pathname} className="animate-fadeIn">
          <Outlet />
        </div>
      </main>
      <BottomNav />
      <Toast />
    </div>
  )
}
