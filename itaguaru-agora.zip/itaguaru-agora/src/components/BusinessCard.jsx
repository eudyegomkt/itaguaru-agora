import React from 'react'
import { Link } from 'react-router-dom'
import { FiPhone } from 'react-icons/fi'

export default function BusinessCard({ business }) {
  return (
    <Link to={`/guia/${business.id}`} className="flex items-center gap-3 rounded-2xl bg-white p-3 shadow-card active:scale-[0.98] transition-transform">
      <img src={business.logo} alt={business.nome} className="h-14 w-14 shrink-0 rounded-xl object-cover" />
      <div className="flex-1 min-w-0">
        <p className="font-display font-semibold text-navy-900 text-sm truncate">{business.nome}</p>
        <span className="text-[11px] text-brick-500 font-medium">{business.categoria}</span>
        <div className="flex items-center gap-1 mt-1 text-navy-400 text-[11px]">
          <FiPhone size={11} />
          <span>{business.telefone}</span>
        </div>
      </div>
    </Link>
  )
}
