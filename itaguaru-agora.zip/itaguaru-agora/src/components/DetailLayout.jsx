import React from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import Header from './Header'
import Toast from './Toast'

export default function DetailLayout({ title }) {
  const location = useLocation()
  return (
    <div className="app-shell flex flex-col">
      <Header title={title} showBack />
      <main className="flex-1 overflow-y-auto no-scrollbar">
        <div key={location.pathname} className="animate-fadeIn">
          <Outlet />
        </div>
      </main>
      <Toast />
    </div>
  )
}
