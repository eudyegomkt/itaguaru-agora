import React from 'react'
import { Link } from 'react-router-dom'

export default function ClassifiedCard({ item }) {
  return (
    <Link to={`/classificados/${item.id}`} className="block rounded-2xl overflow-hidden bg-white shadow-card active:scale-[0.98] transition-transform">
      <img src={item.imagem} alt={item.titulo} className="h-28 w-full object-cover" />
      <div className="p-3">
        <span className="text-[10px] font-bold uppercase text-brick-500">{item.tipo}</span>
        <p className="font-display font-semibold text-navy-900 text-[13.5px] leading-snug line-clamp-2 mt-0.5">{item.titulo}</p>
        <p className="text-sm font-bold text-navy-800 mt-1">{item.preco}</p>
      </div>
    </Link>
  )
}
