import React, { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import SearchBar from '../components/SearchBar'
import CategoryFilter from '../components/CategoryFilter'
import NewsCard from '../components/NewsCard'
import EmptyState from '../components/EmptyState'
import { CardSkeleton } from '../components/Loading'
import { getAllNews, getNewsByCategory, searchNews, CATEGORIAS_NOTICIAS } from '../services/newsService'
import { FiFileText } from 'react-icons/fi'

export default function News() {
  const [searchParams] = useSearchParams()
  const [category, setCategory] = useState(null)
  const [query, setQuery] = useState(searchParams.get('busca') || '')
  const [news, setNews] = useState(null)

  useEffect(() => {
    setNews(null)
    const run = async () => {
      let result
      if (query.trim()) result = await searchNews(query)
      else result = await getNewsByCategory(category)
      setNews(result)
    }
    run()
  }, [category, query])

  return (
    <div className="px-4 pt-3 pb-4">
      <div className="mb-3">
        <SearchBar value={query} onChange={setQuery} placeholder="Buscar notícias" />
      </div>
      <div className="mb-4">
        <CategoryFilter categories={CATEGORIAS_NOTICIAS} active={category} onChange={setCategory} />
      </div>

      {news === null ? (
        <div className="grid grid-cols-2 gap-3">
          {Array.from({ length: 6 }).map((_, i) => <CardSkeleton key={i} />)}
        </div>
      ) : news.length === 0 ? (
        <EmptyState icon={FiFileText} title="Nenhuma notícia encontrada" subtitle="Tente outra categoria ou termo de busca." />
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {news.map((n) => (
            <NewsCard key={n.id} news={n} />
          ))}
        </div>
      )}
    </div>
  )
}
