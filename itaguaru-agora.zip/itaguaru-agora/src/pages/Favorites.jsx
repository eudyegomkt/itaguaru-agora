import React, { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { NewsCardHorizontal } from '../components/NewsCard'
import EventCard from '../components/EventCard'
import EmptyState from '../components/EmptyState'
import { FiHeart } from 'react-icons/fi'
import { useApp } from '../context/AppContext'
import { getAllNews } from '../services/newsService'
import { getAllEvents } from '../services/eventsService'

export default function Favorites() {
  const [searchParams, setSearchParams] = useSearchParams()
  const aba = searchParams.get('aba') || 'noticias'
  const { savedNews, savedEvents } = useApp()
  const [allNews, setAllNews] = useState([])
  const [allEvents, setAllEvents] = useState([])

  useEffect(() => {
    getAllNews().then(setAllNews)
    getAllEvents().then(setAllEvents)
  }, [])

  const newsFiltered = allNews.filter((n) => savedNews.includes(n.id))
  const eventsFiltered = allEvents.filter((e) => savedEvents.includes(e.id))

  return (
    <div className="px-4 pt-3 pb-4">
      <div className="flex gap-2 mb-4">
        {[
          ['noticias', 'Notícias'],
          ['eventos', 'Eventos']
        ].map(([key, label]) => (
          <button
            key={key}
            onClick={() => setSearchParams({ aba: key })}
            className={`flex-1 rounded-xl py-2.5 text-sm font-semibold transition-colors ${
              aba === key ? 'bg-navy-800 text-white' : 'bg-white text-navy-600 shadow-card'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {aba === 'noticias' ? (
        newsFiltered.length === 0 ? (
          <EmptyState icon={FiHeart} title="Nenhuma notícia salva" subtitle="Toque no ícone de salvar em uma notícia para vê-la aqui." />
        ) : (
          <div className="space-y-2.5">
            {newsFiltered.map((n) => (
              <NewsCardHorizontal key={n.id} news={n} />
            ))}
          </div>
        )
      ) : eventsFiltered.length === 0 ? (
        <EmptyState icon={FiHeart} title="Nenhum evento salvo" subtitle="Adicione eventos ao calendário para vê-los aqui." />
      ) : (
        <div className="space-y-2.5">
          {eventsFiltered.map((e) => (
            <EventCard key={e.id} event={e} compact />
          ))}
        </div>
      )}
    </div>
  )
}
