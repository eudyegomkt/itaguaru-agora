import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import logo from '../assets/logo.png'

export default function Splash() {
  const navigate = useNavigate()

  useEffect(() => {
    const t = setTimeout(() => navigate('/login', { replace: true }), 2200)
    return () => clearTimeout(t)
  }, [navigate])

  return (
    <div className="flex h-full min-h-[100dvh] flex-col items-center justify-center bg-navy-900 px-8">
      <div className="animate-fadeIn flex flex-col items-center">
        <div className="bg-white rounded-3xl p-5 shadow-2xl animate-slideUp">
          <img src={logo} alt="Itaguaru Agora" className="h-14 w-auto object-contain" />
        </div>
        <p className="mt-5 text-navy-200 text-sm tracking-wide font-body animate-slideUp" style={{ animationDelay: '.15s' }}>
          O portal oficial de notícias de Itaguaru
        </p>
      </div>

      <div className="absolute bottom-14 flex flex-col items-center gap-3">
        <div className="flex gap-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-brick-500 animate-pulseSlow" />
          <span className="h-1.5 w-1.5 rounded-full bg-brick-500 animate-pulseSlow" style={{ animationDelay: '.2s' }} />
          <span className="h-1.5 w-1.5 rounded-full bg-brick-500 animate-pulseSlow" style={{ animationDelay: '.4s' }} />
        </div>
        <p className="text-navy-400 text-xs">Carregando…</p>
      </div>
    </div>
  )
}
