import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { FiMapPin, FiBriefcase, FiDollarSign, FiCheckCircle } from 'react-icons/fi'
import Loading from '../components/Loading'
import EmptyState from '../components/EmptyState'
import Button from '../components/Button'
import { getJobById } from '../services/jobsService'
import { useApp } from '../context/AppContext'

export default function JobDetail() {
  const { id } = useParams()
  const [job, setJob] = useState(undefined)
  const [candidatado, setCandidatado] = useState(false)
  const { showToast } = useApp()

  useEffect(() => {
    setJob(undefined)
    getJobById(id).then(setJob)
  }, [id])

  if (job === undefined) return <Loading />
  if (job === null) return <EmptyState title="Vaga não encontrada" />

  function handleApply() {
    setCandidatado(true)
    showToast('Candidatura enviada com sucesso!', 'success')
  }

  return (
    <div className="px-4 pt-5 pb-8 animate-fadeIn">
      <span className="inline-block text-[11px] font-bold uppercase tracking-wide text-white bg-navy-800 px-2.5 py-1 rounded-full mb-3">
        {job.tipo}
      </span>
      <h1 className="font-display font-bold text-2xl text-navy-900 leading-tight mb-1">{job.cargo}</h1>
      <p className="text-navy-500 font-medium mb-5">{job.empresa}</p>

      <div className="space-y-3 mb-6">
        <div className="flex items-center gap-3 text-sm text-navy-700">
          <FiMapPin size={17} className="text-navy-400" /> {job.cidade}
        </div>
        <div className="flex items-center gap-3 text-sm text-navy-700">
          <FiDollarSign size={17} className="text-navy-400" /> {job.salario || 'Salário a combinar'}
        </div>
        <div className="flex items-center gap-3 text-sm text-navy-700">
          <FiBriefcase size={17} className="text-navy-400" /> {job.tipo}
        </div>
      </div>

      <h2 className="font-display font-semibold text-navy-900 mb-2">Descrição da vaga</h2>
      <p className="text-[15px] leading-relaxed text-navy-700 mb-5">{job.descricao}</p>

      <h2 className="font-display font-semibold text-navy-900 mb-2">Requisitos</h2>
      <ul className="space-y-2 mb-8">
        {job.requisitos.map((r, i) => (
          <li key={i} className="flex items-start gap-2 text-sm text-navy-700">
            <FiCheckCircle size={16} className="text-brick-500 mt-0.5 shrink-0" /> {r}
          </li>
        ))}
      </ul>

      <Button variant={candidatado ? 'outline' : 'accent'} full disabled={candidatado} onClick={handleApply}>
        {candidatado ? 'Candidatura enviada' : 'Candidatar-se'}
      </Button>
    </div>
  )
}
