import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { FiShare2, FiHeart, FiBookmark, FiUser, FiClock } from 'react-icons/fi'
import Loading from '../components/Loading'
import EmptyState from '../components/EmptyState'
import { getNewsById } from '../services/newsService'
import { useApp } from '../context/AppContext'

function formatDate(iso) {
  const d = new Date(iso + 'T00:00:00')
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })
}

export default function NewsDetail() {
  const { id } = useParams()
  const [news, setNews] = useState(undefined)
  const [liked, setLiked] = useState(false)
  const { savedNews, toggleSavedNews, showToast } = useApp()

  useEffect(() => {
    setNews(undefined)
    getNewsById(id).then(setNews)
  }, [id])

  if (news === undefined) return <Loading />
  if (news === null) return <EmptyState title="Notícia não encontrada" />

  const saved = savedNews.includes(news.id)

  function handleShare() {
    if (navigator.share) {
      navigator.share({ title: news.titulo, text: news.resumo }).catch(() => {})
    } else {
      showToast('Link copiado para a área de transferência', 'success')
    }
  }

  return (
    <div className="pb-8 animate-fadeIn">
      <img src={news.imagem} alt={news.titulo} className="h-64 w-full object-cover" />
      <div className="px-4 pt-4">
        <span className="inline-block text-[11px] font-bold uppercase tracking-wide text-brick-500 bg-brick-50 px-2.5 py-1 rounded-full mb-3">
          {news.categoria}
        </span>
        <h1 className="font-display font-bold text-2xl text-navy-900 leading-tight mb-3">{news.titulo}</h1>

        <div className="flex items-center gap-4 text-xs text-navy-400 mb-5 pb-5 border-b border-navy-100">
          <span className="flex items-center gap-1.5">
            <FiUser size={13} /> {news.autor}
          </span>
          <span className="flex items-center gap-1.5">
            <FiClock size={13} /> {formatDate(news.data)}
          </span>
        </div>

        <div className="space-y-4 text-[15px] leading-relaxed text-navy-700 whitespace-pre-line">{news.texto}</div>

        <div className="flex items-center gap-3 mt-8 pt-5 border-t border-navy-100">
          <button
            onClick={() => setLiked((v) => !v)}
            className={`flex-1 flex items-center justify-center gap-2 rounded-xl py-3 text-sm font-semibold border transition-colors ${
              liked ? 'bg-brick-50 border-brick-200 text-brick-600' : 'border-navy-200 text-navy-600 hover:bg-navy-50'
            }`}
          >
            <FiHeart size={17} className={liked ? 'fill-brick-500' : ''} /> Curtir
          </button>
          <button
            onClick={() => {
              toggleSavedNews(news.id)
              showToast(saved ? 'Removida dos salvos' : 'Notícia salva!', 'success')
            }}
            className={`flex-1 flex items-center justify-center gap-2 rounded-xl py-3 text-sm font-semibold border transition-colors ${
              saved ? 'bg-navy-50 border-navy-300 text-navy-800' : 'border-navy-200 text-navy-600 hover:bg-navy-50'
            }`}
          >
            <FiBookmark size={17} className={saved ? 'fill-navy-800' : ''} /> Salvar
          </button>
          <button
            onClick={handleShare}
            className="flex-1 flex items-center justify-center gap-2 rounded-xl py-3 text-sm font-semibold border border-navy-200 text-navy-600 hover:bg-navy-50"
          >
            <FiShare2 size={17} /> Compartilhar
          </button>
        </div>
      </div>
    </div>
  )
}
