import React from 'react'
import { useLocation } from 'react-router-dom'
import logo from '../assets/logo.png'

const content = {
  '/sobre': {
    title: 'Sobre o Itaguaru Agora',
    body: `O Itaguaru Agora é o portal oficial de notícias e serviços da cidade de Itaguaru. Reunimos em um só lugar as últimas notícias, eventos, guia comercial, vagas de emprego, classificados e serviços de utilidade pública.

Nosso objetivo é aproximar a comunidade e fortalecer o comércio local, oferecendo informação de qualidade e um canal direto entre moradores, empresas e a Prefeitura.

Este é um MVP (produto mínimo viável) desenvolvido para validar a experiência do aplicativo antes da integração com dados reais.`
  },
  '/privacidade': {
    title: 'Política de Privacidade',
    body: `O Itaguaru Agora respeita a sua privacidade. Neste MVP, todos os dados exibidos são fictícios e nenhuma informação pessoal é enviada a servidores externos — tudo é armazenado localmente no seu dispositivo.

Em uma versão futura com backend real, esta política será atualizada para detalhar coleta, uso e proteção de dados pessoais, em conformidade com a LGPD.`
  },
  '/termos': {
    title: 'Termos de Uso',
    body: `Ao utilizar o Itaguaru Agora, você concorda em fazer uso responsável da plataforma, respeitando os demais usuários e a legislação vigente.

Este aplicativo é um protótipo funcional (MVP) com dados simulados, destinado a demonstrações e testes de experiência do usuário.`
  }
}

export default function StaticPage() {
  const { pathname } = useLocation()
  const page = content[pathname] || content['/sobre']

  return (
    <div className="px-4 pt-6 pb-10 animate-fadeIn">
      <img src={logo} alt="Itaguaru Agora" className="h-9 w-auto object-contain mb-5" />
      <h1 className="font-display font-bold text-xl text-navy-900 mb-4">{page.title}</h1>
      <p className="text-[15px] leading-relaxed text-navy-700 whitespace-pre-line">{page.body}</p>
    </div>
  )
}
