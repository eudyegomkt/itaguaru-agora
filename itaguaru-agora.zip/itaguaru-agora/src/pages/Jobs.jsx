import React, { useEffect, useState } from 'react'
import JobCard from '../components/JobCard'
import EmptyState from '../components/EmptyState'
import { ListSkeleton } from '../components/Loading'
import { getAllJobs } from '../services/jobsService'
import { FiBriefcase } from 'react-icons/fi'

export default function Jobs() {
  const [jobs, setJobs] = useState(null)

  useEffect(() => {
    getAllJobs().then(setJobs)
  }, [])

  return (
    <div className="px-4 pt-3 pb-4">
      {jobs === null ? (
        <ListSkeleton count={5} />
      ) : jobs.length === 0 ? (
        <EmptyState icon={FiBriefcase} title="Nenhuma vaga disponível" subtitle="Novas oportunidades aparecem aqui." />
      ) : (
        <div className="space-y-2.5">
          {jobs.map((j) => (
            <JobCard key={j.id} job={j} />
          ))}
        </div>
      )}
    </div>
  )
}
