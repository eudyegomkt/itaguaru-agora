import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { FiUser, FiMail, FiLock, FiArrowLeft } from 'react-icons/fi'
import Button from '../components/Button'
import { useApp } from '../context/AppContext'

export default function Register() {
  const navigate = useNavigate()
  const { login, showToast } = useApp()
  const [nome, setNome] = useState('')
  const [email, setEmail] = useState('')
  const [senha, setSenha] = useState('')

  function handleSubmit(e) {
    e.preventDefault()
    if (!nome || !email || !senha) {
      showToast('Preencha todos os campos', 'error')
      return
    }
    login(nome, email)
    showToast('Conta criada com sucesso!', 'success')
    navigate('/home', { replace: true })
  }

  return (
    <div className="min-h-[100dvh] bg-sand px-6 py-8 animate-fadeIn">
      <button onClick={() => navigate(-1)} className="p-1.5 -ml-1.5 mb-6 rounded-full hover:bg-navy-100">
        <FiArrowLeft size={20} className="text-navy-800" />
      </button>

      <h1 className="font-display font-bold text-2xl text-navy-900 mb-1">Criar conta</h1>
      <p className="text-navy-500 text-sm mb-7">Junte-se à comunidade do Itaguaru Agora.</p>

      <form onSubmit={handleSubmit} className="space-y-3.5">
        <div className="flex items-center gap-2.5 bg-white rounded-xl px-4 py-3 shadow-card border border-navy-100/60">
          <FiUser size={17} className="text-navy-400" />
          <input
            value={nome}
            onChange={(e) => setNome(e.target.value)}
            placeholder="Nome completo"
            className="flex-1 bg-transparent text-sm outline-none placeholder:text-navy-400"
          />
        </div>
        <div className="flex items-center gap-2.5 bg-white rounded-xl px-4 py-3 shadow-card border border-navy-100/60">
          <FiMail size={17} className="text-navy-400" />
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Seu e-mail"
            className="flex-1 bg-transparent text-sm outline-none placeholder:text-navy-400"
          />
        </div>
        <div className="flex items-center gap-2.5 bg-white rounded-xl px-4 py-3 shadow-card border border-navy-100/60">
          <FiLock size={17} className="text-navy-400" />
          <input
            type="password"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            placeholder="Crie uma senha"
            className="flex-1 bg-transparent text-sm outline-none placeholder:text-navy-400"
          />
        </div>

        <Button type="submit" variant="accent" full className="mt-2">
          Criar conta
        </Button>
      </form>

      <p className="text-center text-sm text-navy-500 mt-8">
        Já tem conta?{' '}
        <Link to="/login" className="text-brick-500 font-semibold">
          Entrar
        </Link>
      </p>
    </div>
  )
}
