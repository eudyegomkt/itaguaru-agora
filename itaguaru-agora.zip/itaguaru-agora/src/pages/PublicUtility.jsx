import React, { useEffect, useState } from 'react'
import { FiPhone } from 'react-icons/fi'
import { ListSkeleton } from '../components/Loading'
import { getPublicUtility } from '../services/miscService'

export default function PublicUtility() {
  const [items, setItems] = useState(null)

  useEffect(() => {
    getPublicUtility().then(setItems)
  }, [])

  if (items === null) {
    return (
      <div className="px-4 pt-3 pb-4">
        <ListSkeleton count={6} />
      </div>
    )
  }

  const groups = items.reduce((acc, item) => {
    acc[item.categoria] = acc[item.categoria] || []
    acc[item.categoria].push(item)
    return acc
  }, {})

  return (
    <div className="px-4 pt-3 pb-4 space-y-6">
      {Object.entries(groups).map(([categoria, list]) => (
        <div key={categoria}>
          <h2 className="font-display font-bold text-navy-900 text-[15px] mb-2.5">{categoria}</h2>
          <div className="space-y-2.5">
            {list.map((item, i) => (
              <a
                key={i}
                href={`tel:${item.telefone.replace(/\D/g, '')}`}
                className="flex items-center justify-between rounded-2xl bg-white p-3.5 shadow-card active:scale-[0.98] transition-transform"
              >
                <div className="min-w-0">
                  <p className="font-semibold text-navy-900 text-sm truncate">{item.nome}</p>
                  <p className="text-xs text-navy-400 truncate">{item.descricao}</p>
                </div>
                <div className="flex items-center gap-1.5 shrink-0 ml-2 text-brick-500 font-bold text-sm">
                  <FiPhone size={15} /> {item.telefone}
                </div>
              </a>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}
