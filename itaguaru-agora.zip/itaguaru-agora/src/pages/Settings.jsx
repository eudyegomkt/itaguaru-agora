import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { FiSun, FiMoon, FiGlobe, FiLock, FiFileText, FiInfo, FiChevronRight, FiBell } from 'react-icons/fi'
import { useApp } from '../context/AppContext'

function Row({ icon: Icon, label, to, right }) {
  const Comp = to ? Link : 'div'
  return (
    <Comp to={to} className="flex w-full items-center gap-3 rounded-2xl bg-white px-4 py-3.5 shadow-card">
      <Icon size={19} className="text-navy-500" />
      <span className="flex-1 text-left text-sm font-medium text-navy-800">{label}</span>
      {right || (to && <FiChevronRight size={17} className="text-navy-300" />)}
    </Comp>
  )
}

function Switch({ checked, onChange }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={`h-6 w-11 rounded-full transition-colors relative shrink-0 ${checked ? 'bg-brick-500' : 'bg-navy-200'}`}
    >
      <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${checked ? 'translate-x-5' : 'translate-x-0.5'}`} />
    </button>
  )
}

export default function Settings() {
  const { theme, setTheme } = useApp()
  const [notifications, setNotifications] = useState(true)
  const isDark = theme === 'escuro'

  return (
    <div className="px-4 pt-3 pb-6 space-y-5">
      <div>
        <p className="text-xs font-bold uppercase text-navy-400 mb-2 px-1">Preferências</p>
        <div className="space-y-2.5">
          <Row
            icon={isDark ? FiMoon : FiSun}
            label="Tema escuro"
            right={<Switch checked={isDark} onChange={(v) => setTheme(v ? 'escuro' : 'claro')} />}
          />
          <Row icon={FiBell} label="Notificações" right={<Switch checked={notifications} onChange={setNotifications} />} />
          <Row icon={FiGlobe} label="Idioma" right={<span className="text-xs text-navy-400">Português (BR)</span>} />
        </div>
      </div>

      <div>
        <p className="text-xs font-bold uppercase text-navy-400 mb-2 px-1">Sobre</p>
        <div className="space-y-2.5">
          <Row icon={FiLock} label="Privacidade" to="/privacidade" />
          <Row icon={FiFileText} label="Termos de uso" to="/termos" />
          <Row icon={FiInfo} label="Sobre o app" to="/sobre" />
          <Row icon={FiInfo} label="Versão" right={<span className="text-xs text-navy-400">1.0.0</span>} />
        </div>
      </div>
    </div>
  )
}
