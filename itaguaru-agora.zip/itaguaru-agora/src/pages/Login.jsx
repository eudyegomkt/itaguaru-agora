import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { FiMail, FiLock } from 'react-icons/fi'
import logo from '../assets/logo.png'
import Button from '../components/Button'
import { useApp } from '../context/AppContext'

export default function Login() {
  const navigate = useNavigate()
  const { login, loginAsGuest, showToast } = useApp()
  const [email, setEmail] = useState('')
  const [senha, setSenha] = useState('')

  function handleSubmit(e) {
    e.preventDefault()
    if (!email || !senha) {
      showToast('Preencha e-mail e senha para continuar', 'error')
      return
    }
    login(email.split('@')[0], email)
    showToast('Login realizado com sucesso!', 'success')
    navigate('/home', { replace: true })
  }

  function handleGuest() {
    loginAsGuest()
    navigate('/home', { replace: true })
  }

  return (
    <div className="flex min-h-[100dvh] flex-col justify-center bg-sand px-6 py-10 animate-fadeIn">
      <div className="flex flex-col items-center mb-8">
        <img src={logo} alt="Itaguaru Agora" className="h-12 w-auto object-contain mb-3" />
        <p className="text-navy-500 text-sm text-center">Fique por dentro de tudo que acontece em Itaguaru.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-3.5">
        <div className="flex items-center gap-2.5 bg-white rounded-xl px-4 py-3 shadow-card border border-navy-100/60">
          <FiMail size={17} className="text-navy-400" />
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Seu e-mail"
            className="flex-1 bg-transparent text-sm outline-none placeholder:text-navy-400"
          />
        </div>
        <div className="flex items-center gap-2.5 bg-white rounded-xl px-4 py-3 shadow-card border border-navy-100/60">
          <FiLock size={17} className="text-navy-400" />
          <input
            type="password"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            placeholder="Sua senha"
            className="flex-1 bg-transparent text-sm outline-none placeholder:text-navy-400"
          />
        </div>

        <div className="flex justify-end">
          <Link to="/esqueci-senha" className="text-xs text-navy-500 hover:text-brick-500 font-medium">
            Esqueci minha senha
          </Link>
        </div>

        <Button type="submit" variant="accent" full className="mt-1">
          Entrar
        </Button>
      </form>

      <div className="flex items-center gap-3 my-5">
        <div className="h-px flex-1 bg-navy-100" />
        <span className="text-xs text-navy-400">ou</span>
        <div className="h-px flex-1 bg-navy-100" />
      </div>

      <div className="space-y-3">
        <Button variant="outline" full onClick={() => showToast('Login com Google simulado neste MVP', 'info')}>
          Entrar com Google
        </Button>
        <Button variant="ghost" full onClick={handleGuest}>
          Continuar como visitante
        </Button>
      </div>

      <p className="text-center text-sm text-navy-500 mt-8">
        Não tem conta?{' '}
        <Link to="/criar-conta" className="text-brick-500 font-semibold">
          Criar conta
        </Link>
      </p>
    </div>
  )
}
