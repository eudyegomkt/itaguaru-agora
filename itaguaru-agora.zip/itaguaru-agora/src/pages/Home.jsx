import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { FiChevronRight } from 'react-icons/fi'
import SearchBar from '../components/SearchBar'
import WeatherWidget from '../components/WeatherWidget'
import { NewsCardFeatured, NewsCardHorizontal } from '../components/NewsCard'
import EventCard from '../components/EventCard'
import { CardSkeleton, ListSkeleton } from '../components/Loading'
import { getAllNews, getFeaturedNews } from '../services/newsService'
import { getUpcomingEvents } from '../services/eventsService'
import { getAllBusinesses } from '../services/businessService'
import { getBanners, getWeather } from '../services/miscService'

function SectionTitle({ children, to }) {
  return (
    <div className="flex items-center justify-between px-4 mb-3">
      <h2 className="font-display font-bold text-navy-900 text-[17px]">{children}</h2>
      {to && (
        <Link to={to} className="flex items-center gap-0.5 text-xs font-semibold text-brick-500">
          Ver tudo <FiChevronRight size={14} />
        </Link>
      )}
    </div>
  )
}

export default function Home() {
  const navigate = useNavigate()
  const [banners, setBanners] = useState([])
  const [featured, setFeatured] = useState(null)
  const [latest, setLatest] = useState(null)
  const [events, setEvents] = useState(null)
  const [businesses, setBusinesses] = useState([])
  const [weather, setWeather] = useState(null)
  const [query, setQuery] = useState('')

  useEffect(() => {
    getBanners().then(setBanners)
    getWeather().then(setWeather)
    getFeaturedNews().then(setFeatured)
    getAllNews().then((n) => setLatest(n.slice(0, 6)))
    getUpcomingEvents(4).then(setEvents)
    getAllBusinesses().then((b) => setBusinesses(b.slice(0, 6)))
  }, [])

  function handleSearchSubmit(e) {
    e.preventDefault()
    if (query.trim()) navigate(`/noticias?busca=${encodeURIComponent(query)}`)
  }

  return (
    <div className="pb-2">
      <div className="px-4 pt-3 pb-1">
        <form onSubmit={handleSearchSubmit}>
          <SearchBar value={query} onChange={setQuery} />
        </form>
      </div>

      {/* Banner rotativo */}
      <div className="flex gap-3 overflow-x-auto no-scrollbar px-4 py-3 snap-x snap-mandatory">
        {banners.length === 0
          ? Array.from({ length: 2 }).map((_, i) => <div key={i} className="w-[85%] shrink-0 h-40 rounded-2xl skeleton animate-shimmer" />)
          : banners.map((b) => (
              <Link key={b.id} to={b.link} className="relative w-[85%] shrink-0 snap-center rounded-2xl overflow-hidden shadow-card">
                <img src={b.imagem} alt={b.titulo} className="h-40 w-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-900/85 via-navy-900/10 to-transparent" />
                <p className="absolute bottom-3 left-3.5 right-3.5 text-white font-display font-bold text-[15px] leading-snug">{b.titulo}</p>
              </Link>
            ))}
      </div>

      <p className="px-4 text-center text-xs text-navy-400 italic -mt-1 mb-4">"O portal oficial de notícias de Itaguaru."</p>

      <div className="px-4 mb-5">
        <WeatherWidget weather={weather} />
      </div>

      {/* Notícias em destaque */}
      <SectionTitle to="/noticias">Notícias em destaque</SectionTitle>
      <div className="flex gap-3 overflow-x-auto no-scrollbar px-4 pb-5">
        {featured === null
          ? Array.from({ length: 2 }).map((_, i) => <div key={i} className="w-[78%] shrink-0 h-44 rounded-2xl skeleton animate-shimmer" />)
          : featured.map((n) => <NewsCardFeatured key={n.id} news={n} />)}
      </div>

      {/* Últimas notícias */}
      <SectionTitle to="/noticias">Últimas notícias</SectionTitle>
      <div className="px-4 pb-5">
        {latest === null ? <ListSkeleton count={3} /> : (
          <div className="space-y-2.5">
            {latest.map((n) => (
              <NewsCardHorizontal key={n.id} news={n} />
            ))}
          </div>
        )}
      </div>

      {/* Eventos próximos */}
      <SectionTitle to="/eventos">Eventos próximos</SectionTitle>
      <div className="flex gap-3 overflow-x-auto no-scrollbar px-4 pb-5">
        {events === null
          ? Array.from({ length: 2 }).map((_, i) => <div key={i} className="w-[70%] shrink-0 h-52 rounded-2xl skeleton animate-shimmer" />)
          : events.map((e) => (
              <div key={e.id} className="w-[70%] shrink-0">
                <EventCard event={e} />
              </div>
            ))}
      </div>

      {/* Empresas patrocinadas */}
      <SectionTitle to="/guia">Empresas patrocinadas</SectionTitle>
      <div className="flex gap-3 overflow-x-auto no-scrollbar px-4 pb-2">
        {businesses.length === 0
          ? Array.from({ length: 3 }).map((_, i) => <div key={i} className="w-24 shrink-0 h-28 rounded-2xl skeleton animate-shimmer" />)
          : businesses.map((b) => (
              <Link key={b.id} to={`/guia/${b.id}`} className="w-24 shrink-0 flex flex-col items-center gap-1.5 rounded-2xl bg-white p-3 shadow-card active:scale-95 transition-transform">
                <img src={b.logo} alt={b.nome} className="h-12 w-12 rounded-full object-cover" />
                <p className="text-[11px] text-center text-navy-700 font-medium leading-tight line-clamp-2">{b.nome}</p>
              </Link>
            ))}
      </div>
    </div>
  )
}
