import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { FiPhone, FiTag } from 'react-icons/fi'
import Loading from '../components/Loading'
import EmptyState from '../components/EmptyState'
import Button from '../components/Button'
import { getClassifiedById } from '../services/classifiedsService'

export default function ClassifiedDetail() {
  const { id } = useParams()
  const [item, setItem] = useState(undefined)

  useEffect(() => {
    setItem(undefined)
    getClassifiedById(id).then(setItem)
  }, [id])

  if (item === undefined) return <Loading />
  if (item === null) return <EmptyState title="Anúncio não encontrado" />

  return (
    <div className="pb-8 animate-fadeIn">
      <img src={item.imagem} alt={item.titulo} className="h-56 w-full object-cover" />
      <div className="px-4 pt-4">
        <span className="inline-block text-[11px] font-bold uppercase tracking-wide text-brick-500 bg-brick-50 px-2.5 py-1 rounded-full mb-3">
          {item.tipo} · {item.categoria}
        </span>
        <h1 className="font-display font-bold text-2xl text-navy-900 leading-tight mb-2">{item.titulo}</h1>
        <p className="font-display font-bold text-2xl text-brick-500 mb-5">{item.preco}</p>

        <p className="text-[15px] leading-relaxed text-navy-700 mb-6">{item.descricao}</p>

        <Button variant="accent" full icon={FiPhone} onClick={() => (window.location.href = `tel:${item.contato}`)}>
          Ligar para {item.contato}
        </Button>
      </div>
    </div>
  )
}
