import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { FiMail, FiArrowLeft, FiCheckCircle } from 'react-icons/fi'
import Button from '../components/Button'

export default function ForgotPassword() {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [enviado, setEnviado] = useState(false)

  function handleSubmit(e) {
    e.preventDefault()
    setEnviado(true)
  }

  return (
    <div className="min-h-[100dvh] bg-sand px-6 py-8 animate-fadeIn">
      <button onClick={() => navigate(-1)} className="p-1.5 -ml-1.5 mb-6 rounded-full hover:bg-navy-100">
        <FiArrowLeft size={20} className="text-navy-800" />
      </button>

      {!enviado ? (
        <>
          <h1 className="font-display font-bold text-2xl text-navy-900 mb-1">Esqueci minha senha</h1>
          <p className="text-navy-500 text-sm mb-7">Informe seu e-mail para receber o link de redefinição.</p>

          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div className="flex items-center gap-2.5 bg-white rounded-xl px-4 py-3 shadow-card border border-navy-100/60">
              <FiMail size={17} className="text-navy-400" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Seu e-mail"
                className="flex-1 bg-transparent text-sm outline-none placeholder:text-navy-400"
              />
            </div>
            <Button type="submit" variant="accent" full>
              Enviar link de redefinição
            </Button>
          </form>
        </>
      ) : (
        <div className="flex flex-col items-center text-center pt-16 animate-fadeIn">
          <FiCheckCircle size={48} className="text-brick-500 mb-4" />
          <h2 className="font-display font-bold text-xl text-navy-900 mb-2">E-mail enviado!</h2>
          <p className="text-navy-500 text-sm max-w-[260px]">
            Se {email || 'esse e-mail'} estiver cadastrado, você receberá as instruções em instantes.
          </p>
          <Button variant="ghost" className="mt-6" onClick={() => navigate('/login')}>
            Voltar ao login
          </Button>
        </div>
      )}
    </div>
  )
}
