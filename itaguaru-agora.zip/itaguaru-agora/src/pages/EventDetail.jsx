import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { FiMapPin, FiCalendar, FiClock, FiPlusCircle } from 'react-icons/fi'
import Loading from '../components/Loading'
import EmptyState from '../components/EmptyState'
import Button from '../components/Button'
import { getEventById } from '../services/eventsService'
import { useApp } from '../context/AppContext'

function formatDate(iso) {
  const d = new Date(iso + 'T00:00:00')
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })
}

export default function EventDetail() {
  const { id } = useParams()
  const [event, setEvent] = useState(undefined)
  const { savedEvents, toggleSavedEvent, showToast } = useApp()

  useEffect(() => {
    setEvent(undefined)
    getEventById(id).then(setEvent)
  }, [id])

  if (event === undefined) return <Loading />
  if (event === null) return <EmptyState title="Evento não encontrado" />

  const saved = savedEvents.includes(event.id)

  function handleAddCalendar() {
    toggleSavedEvent(event.id)
    showToast(saved ? 'Removido do calendário' : 'Adicionado ao calendário!', 'success')
  }

  return (
    <div className="pb-8 animate-fadeIn">
      <img src={event.imagem} alt={event.titulo} className="h-64 w-full object-cover" />
      <div className="px-4 pt-4">
        <span className="inline-block text-[11px] font-bold uppercase tracking-wide text-brick-500 bg-brick-50 px-2.5 py-1 rounded-full mb-3">
          {event.categoria}
        </span>
        <h1 className="font-display font-bold text-2xl text-navy-900 leading-tight mb-4">{event.titulo}</h1>

        <div className="space-y-3 mb-5">
          <div className="flex items-center gap-3 text-sm text-navy-700">
            <FiCalendar size={17} className="text-navy-400" /> {formatDate(event.data)}
          </div>
          <div className="flex items-center gap-3 text-sm text-navy-700">
            <FiClock size={17} className="text-navy-400" /> {event.horario}
          </div>
          <div className="flex items-center gap-3 text-sm text-navy-700">
            <FiMapPin size={17} className="text-navy-400" /> {event.local}, {event.cidade}
          </div>
        </div>

        <p className="text-[15px] leading-relaxed text-navy-700 mb-6">{event.descricao}</p>

        <Button variant={saved ? 'outline' : 'accent'} full icon={FiPlusCircle} onClick={handleAddCalendar}>
          {saved ? 'Remover do calendário' : 'Adicionar ao calendário'}
        </Button>
      </div>
    </div>
  )
}
