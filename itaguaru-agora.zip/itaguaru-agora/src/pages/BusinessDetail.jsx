import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { FiPhone, FiMessageCircle, FiInstagram, FiMapPin, FiClock } from 'react-icons/fi'
import Loading from '../components/Loading'
import EmptyState from '../components/EmptyState'
import Button from '../components/Button'
import { getBusinessById } from '../services/businessService'

export default function BusinessDetail() {
  const { id } = useParams()
  const [business, setBusiness] = useState(undefined)

  useEffect(() => {
    setBusiness(undefined)
    getBusinessById(id).then(setBusiness)
  }, [id])

  if (business === undefined) return <Loading />
  if (business === null) return <EmptyState title="Empresa não encontrada" />

  return (
    <div className="pb-8 animate-fadeIn">
      <img src={business.foto} alt={business.nome} className="h-52 w-full object-cover" />
      <div className="px-4 pt-4">
        <div className="flex items-center gap-3 -mt-14 mb-4">
          <img src={business.logo} alt={business.nome} className="h-20 w-20 rounded-2xl object-cover ring-4 ring-white shadow-card" />
        </div>

        <span className="inline-block text-[11px] font-bold uppercase tracking-wide text-brick-500 bg-brick-50 px-2.5 py-1 rounded-full mb-2">
          {business.categoria}
        </span>
        <h1 className="font-display font-bold text-2xl text-navy-900 leading-tight mb-3">{business.nome}</h1>
        <p className="text-[15px] leading-relaxed text-navy-700 mb-5">{business.descricao}</p>

        <div className="space-y-3 mb-6">
          <div className="flex items-center gap-3 text-sm text-navy-700">
            <FiClock size={17} className="text-navy-400 shrink-0" /> {business.horario}
          </div>
          <div className="flex items-center gap-3 text-sm text-navy-700">
            <FiPhone size={17} className="text-navy-400 shrink-0" /> {business.telefone}
          </div>
          <div className="flex items-center gap-3 text-sm text-navy-700">
            <FiInstagram size={17} className="text-navy-400 shrink-0" /> {business.instagram}
          </div>
          <div className="flex items-center gap-3 text-sm text-navy-700">
            <FiMapPin size={17} className="text-navy-400 shrink-0" /> {business.endereco}
          </div>
        </div>

        <div className="rounded-2xl overflow-hidden shadow-card mb-6 h-40">
          <iframe
            title="mapa"
            className="w-full h-full border-0"
            loading="lazy"
            src={`https://maps.google.com/maps?q=${business.lat},${business.lng}&z=15&output=embed`}
          />
        </div>

        <div className="flex gap-3">
          <Button variant="accent" full icon={FiPhone} onClick={() => (window.location.href = `tel:${business.telefone}`)}>
            Ligar
          </Button>
          <Button
            variant="outline"
            full
            icon={FiMessageCircle}
            onClick={() => window.open(`https://wa.me/${business.whatsapp}`, '_blank')}
          >
            Mensagem
          </Button>
        </div>
      </div>
    </div>
  )
}
