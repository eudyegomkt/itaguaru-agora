import React, { useEffect, useState } from 'react'
import EventCard from '../components/EventCard'
import EmptyState from '../components/EmptyState'
import { ListSkeleton } from '../components/Loading'
import { getAllEvents } from '../services/eventsService'
import { FiCalendar } from 'react-icons/fi'

export default function Events() {
  const [events, setEvents] = useState(null)

  useEffect(() => {
    getAllEvents().then(setEvents)
  }, [])

  return (
    <div className="px-4 pt-3 pb-4">
      {events === null ? (
        <ListSkeleton count={5} />
      ) : events.length === 0 ? (
        <EmptyState icon={FiCalendar} title="Nenhum evento no momento" subtitle="Volte em breve para conferir a agenda da cidade." />
      ) : (
        <div className="space-y-3">
          {events.map((e) => (
            <EventCard key={e.id} event={e} />
          ))}
        </div>
      )}
    </div>
  )
}
