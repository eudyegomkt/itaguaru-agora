import React, { useEffect, useState } from 'react'
import CategoryFilter from '../components/CategoryFilter'
import ClassifiedCard from '../components/ClassifiedCard'
import EmptyState from '../components/EmptyState'
import { CardSkeleton } from '../components/Loading'
import { getClassifiedsByCategory, CATEGORIAS_CLASSIFICADOS } from '../services/classifiedsService'
import { FiTag } from 'react-icons/fi'

export default function Classifieds() {
  const [category, setCategory] = useState(null)
  const [items, setItems] = useState(null)

  useEffect(() => {
    setItems(null)
    getClassifiedsByCategory(category).then(setItems)
  }, [category])

  return (
    <div className="px-4 pt-3 pb-4">
      <div className="mb-4">
        <CategoryFilter categories={CATEGORIAS_CLASSIFICADOS} active={category} onChange={setCategory} />
      </div>

      {items === null ? (
        <div className="grid grid-cols-2 gap-3">
          {Array.from({ length: 6 }).map((_, i) => <CardSkeleton key={i} />)}
        </div>
      ) : items.length === 0 ? (
        <EmptyState icon={FiTag} title="Nenhum classificado por aqui" subtitle="Seja o primeiro a publicar um anúncio." />
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {items.map((c) => (
            <ClassifiedCard key={c.id} item={c} />
          ))}
        </div>
      )}
    </div>
  )
}
