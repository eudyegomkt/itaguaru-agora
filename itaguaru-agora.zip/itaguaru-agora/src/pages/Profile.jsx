import React from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { FiHeart, FiBookmark, FiCalendar, FiSettings, FiLogOut, FiChevronRight } from 'react-icons/fi'
import { useApp } from '../context/AppContext'

function Row({ icon: Icon, label, to, onClick, danger }) {
  const Comp = to ? Link : 'button'
  return (
    <Comp
      to={to}
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-2xl bg-white px-4 py-3.5 shadow-card active:scale-[0.98] transition-transform ${
        danger ? 'text-brick-600' : 'text-navy-800'
      }`}
    >
      <Icon size={19} className={danger ? 'text-brick-500' : 'text-navy-500'} />
      <span className="flex-1 text-left text-sm font-medium">{label}</span>
      {!danger && <FiChevronRight size={17} className="text-navy-300" />}
    </Comp>
  )
}

export default function Profile() {
  const navigate = useNavigate()
  const { user, logout, savedNews, savedEvents } = useApp()

  function handleLogout() {
    logout()
    navigate('/login', { replace: true })
  }

  return (
    <div className="px-4 pt-3 pb-6">
      <div className="flex items-center gap-4 rounded-2xl bg-white p-4 shadow-card mb-5">
        <div className="h-16 w-16 rounded-full bg-navy-800 flex items-center justify-center text-white font-display font-bold text-xl">
          {(user?.nome || 'V')[0].toUpperCase()}
        </div>
        <div className="min-w-0">
          <p className="font-display font-bold text-navy-900 text-lg truncate">{user?.nome || 'Visitante'}</p>
          <p className="text-xs text-navy-400 truncate">{user?.email || 'Modo visitante'}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-5">
        <div className="rounded-2xl bg-white p-4 shadow-card text-center">
          <p className="font-display font-bold text-navy-900 text-2xl">{savedNews.length}</p>
          <p className="text-xs text-navy-400">Notícias salvas</p>
        </div>
        <div className="rounded-2xl bg-white p-4 shadow-card text-center">
          <p className="font-display font-bold text-navy-900 text-2xl">{savedEvents.length}</p>
          <p className="text-xs text-navy-400">Eventos salvos</p>
        </div>
      </div>

      <div className="space-y-2.5">
        <Row icon={FiHeart} label="Favoritos" to="/favoritos" />
        <Row icon={FiBookmark} label="Notícias salvas" to="/favoritos?aba=noticias" />
        <Row icon={FiCalendar} label="Eventos salvos" to="/favoritos?aba=eventos" />
        <Row icon={FiSettings} label="Configurações" to="/configuracoes" />
        <Row icon={FiLogOut} label="Sair" onClick={handleLogout} danger />
      </div>
    </div>
  )
}
