import React, { useEffect, useState } from 'react'
import SearchBar from '../components/SearchBar'
import CategoryFilter from '../components/CategoryFilter'
import BusinessCard from '../components/BusinessCard'
import EmptyState from '../components/EmptyState'
import { ListSkeleton } from '../components/Loading'
import { getBusinessesByCategory, searchBusinesses, CATEGORIAS_GUIA } from '../services/businessService'
import { FiGrid } from 'react-icons/fi'

export default function Guide() {
  const [category, setCategory] = useState(null)
  const [query, setQuery] = useState('')
  const [businesses, setBusinesses] = useState(null)

  useEffect(() => {
    setBusinesses(null)
    const run = async () => {
      const result = query.trim() ? await searchBusinesses(query) : await getBusinessesByCategory(category)
      setBusinesses(result)
    }
    run()
  }, [category, query])

  return (
    <div className="px-4 pt-3 pb-4">
      <div className="mb-3">
        <SearchBar value={query} onChange={setQuery} placeholder="Buscar empresas" />
      </div>
      <div className="mb-4">
        <CategoryFilter categories={CATEGORIAS_GUIA} active={category} onChange={setCategory} />
      </div>

      {businesses === null ? (
        <ListSkeleton count={5} />
      ) : businesses.length === 0 ? (
        <EmptyState icon={FiGrid} title="Nenhuma empresa encontrada" subtitle="Tente outra categoria ou termo de busca." />
      ) : (
        <div className="space-y-2.5">
          {businesses.map((b) => (
            <BusinessCard key={b.id} business={b} />
          ))}
        </div>
      )}
    </div>
  )
}
