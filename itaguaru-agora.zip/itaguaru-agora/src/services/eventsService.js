import eventsData from '../data/events.json'

const delay = (ms = 300) => new Promise((res) => setTimeout(res, ms))

export async function getAllEvents() {
  await delay()
  return [...eventsData].sort((a, b) => new Date(a.data) - new Date(b.data))
}

export async function getEventById(id) {
  await delay(200)
  return eventsData.find((e) => String(e.id) === String(id)) || null
}

export async function getUpcomingEvents(limit = 5) {
  await delay(250)
  return [...eventsData].sort((a, b) => new Date(a.data) - new Date(b.data)).slice(0, limit)
}
