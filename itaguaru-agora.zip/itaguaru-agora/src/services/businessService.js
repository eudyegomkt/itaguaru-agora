import businessData from '../data/businesses.json'

const delay = (ms = 300) => new Promise((res) => setTimeout(res, ms))

export const CATEGORIAS_GUIA = ['Restaurantes', 'Lojas', 'Mercados', 'Farmácias', 'Postos', 'Mecânicas', 'Pizzarias', 'Academias', 'Advogados', 'Dentistas']

export async function getAllBusinesses() {
  await delay()
  return businessData
}

export async function getBusinessesByCategory(categoria) {
  await delay()
  if (!categoria || categoria === 'Todas') return getAllBusinesses()
  return businessData.filter((b) => b.categoria === categoria)
}

export async function getBusinessById(id) {
  await delay(200)
  return businessData.find((b) => String(b.id) === String(id)) || null
}

export async function searchBusinesses(query) {
  await delay(200)
  const q = query.trim().toLowerCase()
  if (!q) return getAllBusinesses()
  return businessData.filter((b) => b.nome.toLowerCase().includes(q) || b.categoria.toLowerCase().includes(q))
}
