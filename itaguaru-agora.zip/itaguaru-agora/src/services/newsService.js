import newsData from '../data/news.json'

// Simula latência de rede. Quando houver backend real, troque o corpo
// destas funções por chamadas fetch('/api/noticias') mantendo a mesma assinatura.
const delay = (ms = 350) => new Promise((res) => setTimeout(res, ms))

export async function getAllNews() {
  await delay()
  return [...newsData].sort((a, b) => new Date(b.data) - new Date(a.data))
}

export async function getFeaturedNews() {
  await delay(250)
  return newsData.filter((n) => n.destaque)
}

export async function getNewsByCategory(categoria) {
  await delay()
  if (!categoria || categoria === 'Todas') return getAllNews()
  return newsData.filter((n) => n.categoria === categoria)
}

export async function getNewsById(id) {
  await delay(200)
  return newsData.find((n) => String(n.id) === String(id)) || null
}

export async function searchNews(query) {
  await delay(200)
  const q = query.trim().toLowerCase()
  if (!q) return getAllNews()
  return newsData.filter(
    (n) => n.titulo.toLowerCase().includes(q) || n.resumo.toLowerCase().includes(q) || n.categoria.toLowerCase().includes(q)
  )
}

export const CATEGORIAS_NOTICIAS = ['Política', 'Cidade', 'Esportes', 'Saúde', 'Educação', 'Segurança', 'Agronegócio', 'Eventos']
