import publicUtilityData from '../data/publicUtility.json'
import bannersData from '../data/banners.json'
import weatherData from '../data/weather.json'

const delay = (ms = 250) => new Promise((res) => setTimeout(res, ms))

export async function getPublicUtility() {
  await delay()
  return publicUtilityData
}

export async function getBanners() {
  await delay(200)
  return bannersData
}

export async function getWeather() {
  await delay(150)
  return weatherData
}
