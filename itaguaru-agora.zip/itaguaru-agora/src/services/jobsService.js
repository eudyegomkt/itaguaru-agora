import jobsData from '../data/jobs.json'

const delay = (ms = 300) => new Promise((res) => setTimeout(res, ms))

export async function getAllJobs() {
  await delay()
  return [...jobsData].sort((a, b) => new Date(b.publicadaEm) - new Date(a.publicadaEm))
}

export async function getJobById(id) {
  await delay(200)
  return jobsData.find((j) => String(j.id) === String(id)) || null
}
