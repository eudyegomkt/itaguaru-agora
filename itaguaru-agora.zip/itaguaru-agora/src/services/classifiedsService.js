import classifiedsData from '../data/classifieds.json'

const delay = (ms = 300) => new Promise((res) => setTimeout(res, ms))

export const CATEGORIAS_CLASSIFICADOS = ['Veículos', 'Imóveis', 'Animais', 'Serviços']

export async function getAllClassifieds() {
  await delay()
  return classifiedsData
}

export async function getClassifiedsByCategory(categoria) {
  await delay()
  if (!categoria || categoria === 'Todas') return getAllClassifieds()
  return classifiedsData.filter((c) => c.categoria === categoria)
}

export async function getClassifiedById(id) {
  await delay(200)
  return classifiedsData.find((c) => String(c.id) === String(id)) || null
}
