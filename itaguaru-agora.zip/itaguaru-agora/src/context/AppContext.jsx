import React, { createContext, useContext, useEffect, useState, useCallback } from 'react'

const AppContext = createContext(null)

const STORAGE_KEY = 'itaguaru-agora:state'

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) return JSON.parse(raw)
  } catch (e) {
    // ignora estado corrompido
  }
  return { user: null, savedNews: [], savedEvents: [], theme: 'claro' }
}

export function AppProvider({ children }) {
  const [state, setState] = useState(loadState)
  const [toast, setToast] = useState(null)

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
  }, [state])

  const showToast = useCallback((message, type = 'info') => {
    setToast({ message, type, id: Date.now() })
  }, [])

  useEffect(() => {
    if (!toast) return
    const t = setTimeout(() => setToast(null), 2600)
    return () => clearTimeout(t)
  }, [toast])

  const login = useCallback((nome, email) => {
    setState((s) => ({ ...s, user: { nome, email, visitante: false } }))
  }, [])

  const loginAsGuest = useCallback(() => {
    setState((s) => ({ ...s, user: { nome: 'Visitante', email: null, visitante: true } }))
  }, [])

  const logout = useCallback(() => {
    setState((s) => ({ ...s, user: null }))
  }, [])

  const toggleSavedNews = useCallback((id) => {
    setState((s) => {
      const has = s.savedNews.includes(id)
      return { ...s, savedNews: has ? s.savedNews.filter((n) => n !== id) : [...s.savedNews, id] }
    })
  }, [])

  const toggleSavedEvent = useCallback((id) => {
    setState((s) => {
      const has = s.savedEvents.includes(id)
      return { ...s, savedEvents: has ? s.savedEvents.filter((n) => n !== id) : [...s.savedEvents, id] }
    })
  }, [])

  const setTheme = useCallback((theme) => {
    setState((s) => ({ ...s, theme }))
  }, [])

  const value = {
    user: state.user,
    savedNews: state.savedNews,
    savedEvents: state.savedEvents,
    theme: state.theme,
    login,
    loginAsGuest,
    logout,
    toggleSavedNews,
    toggleSavedEvent,
    setTheme,
    toast,
    showToast
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp deve ser usado dentro de <AppProvider>')
  return ctx
}
