O script `generate-data.cjs` que gerou os arquivos em `src/data/*.json` foi usado apenas
uma vez durante a criação deste MVP e removido do pacote final para manter o projeto limpo.
Os dados fictícios já estão prontos e versionados em `src/data/`. Caso queira gerar novos
dados aleatórios, os mesmos JSONs podem ser editados diretamente — o formato de cada objeto
está documentado pelo uso nas telas correspondentes (`src/pages/`) e nos serviços (`src/services/`).
