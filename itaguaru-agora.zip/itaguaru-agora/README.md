# Itaguaru Agora — MVP

MVP funcional do aplicativo **Itaguaru Agora**, portal oficial de notícias e serviços da cidade de Itaguaru. Construído com **React + React Router + Tailwind CSS**, com dados simulados em JSON prontos para serem substituídos por uma API real.

## ✨ Identidade visual

Extraída da logomarca oficial:
- **Azul-marinho** (`navy`) — cor principal da marca e do texto "itaguaru"
- **Vermelho** (`brick`) — cor de destaque, usada no balão "AGORA"
- **Tipografia**: Sora (display, títulos) + Inter (corpo de texto)
- Modo claro, cards elegantes, bordas arredondadas, sombras suaves e animações discretas (fade, slide, shimmer em skeletons)

## 🗂️ Estrutura do projeto

```
itaguaru-agora/
├── src/
│   ├── assets/          # logo e imagens estáticas
│   ├── components/      # componentes reutilizáveis (Header, BottomNav, Drawer, Cards, etc.)
│   ├── context/         # estado global (auth simulado, favoritos, tema, toast)
│   ├── data/             # JSONs com dados fictícios de Itaguaru
│   ├── pages/            # as 13 telas do app
│   ├── services/         # camada de acesso a dados (fácil trocar por fetch/API)
│   ├── App.jsx           # definição de todas as rotas
│   ├── main.jsx          # entrypoint da aplicação
│   └── index.css         # Tailwind + estilos globais
├── scripts/
│   └── README.md          # nota sobre a origem dos dados fictícios
├── index.html
├── tailwind.config.js
├── postcss.config.js
├── vite.config.js
└── package.json
```

## 📱 Telas implementadas

1. Splash Screen (logo + carregamento automático)
2. Login (entrar, criar conta, visitante, Google visual, esqueci senha)
3. Home (banner rotativo, destaque, últimas notícias, eventos, empresas patrocinadas, clima, busca)
4. Notícias (lista, filtros por categoria, busca)
5. Detalhe da notícia (curtir, salvar, compartilhar)
6. Eventos (lista + adicionar ao calendário)
7. Guia Comercial (10 categorias, busca)
8. Detalhe da empresa (mapa, ligar, WhatsApp)
9. Empregos (lista + candidatura simulada)
10. Utilidade Pública (SAMU, hospitais, polícia, prefeitura, etc.)
11. Classificados (veículos, imóveis, animais, serviços)
12. Perfil (favoritos, notícias/eventos salvos, configurações, sair)
13. Configurações (tema, idioma, privacidade, termos, sobre, versão)

Mais o **menu inferior** (Home, Notícias, Eventos, Guia, Perfil) e o **menu lateral** (drawer com todas as seções).

## 🔢 Dados simulados

Gerados em `src/data/*.json`:
- 30 notícias
- 15 eventos
- 23 empresas (guia comercial, 10 categorias)
- 20 vagas de emprego
- 15 classificados
- utilidade pública, banners da home e clima

Os dados já vêm prontos em `src/data/`; veja `scripts/README.md` caso queira entender ou expandir o padrão usado.

## 🔌 Como substituir por uma API real

Toda a leitura de dados passa pela pasta `src/services/`. Cada função (ex: `getAllNews()`, `getEventById(id)`) já simula uma chamada assíncrona com `await`. Para conectar a um backend real, basta trocar o corpo da função por um `fetch`, mantendo a mesma assinatura — nenhuma tela precisa ser alterada.

```js
// antes (simulado)
export async function getAllNews() {
  await delay()
  return newsData
}

// depois (API real)
export async function getAllNews() {
  const res = await fetch('/api/noticias')
  return res.json()
}
```

## ▶️ Como executar localmente

Pré-requisitos: [Node.js](https://nodejs.org) 18+ instalado.

```bash
# 1. Entre na pasta do projeto
cd itaguaru-agora

# 2. Instale as dependências
npm install

# 3. Rode o servidor de desenvolvimento
npm run dev
```

O app abrirá automaticamente em `http://localhost:5173`. Para melhor experiência, abra o DevTools do navegador e simule uma tela de smartphone (Android/iPhone) — o layout foi feito para ficar centralizado em telas maiores, simulando um app nativo.

### Build de produção

```bash
npm run build
npm run preview
```

## 🖼️ Sobre as imagens

As fotos de notícias, eventos, empresas e classificados usam o serviço `picsum.photos` como placeholder (imagens aleatórias com seed fixa, para não trocar a cada recarregamento). Basta trocar os campos `imagem`/`foto`/`logo` nos arquivos JSON de `src/data/` por URLs reais ou caminhos locais quando o conteúdo definitivo estiver disponível.

## 🚀 Próximos passos sugeridos

- Conectar `src/services/` a uma API/backend real (Node, Firebase, Supabase etc.)
- Autenticação real (JWT, OAuth do Google)
- Push notifications
- Painel administrativo para a Prefeitura/redação cadastrar notícias e eventos
- Publicação como PWA ou empacotamento com Capacitor para Android/iOS
