/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          50: '#eef2f7',
          100: '#d7e0ec',
          200: '#b0c1d9',
          300: '#88a2c6',
          400: '#5c7ba8',
          500: '#3a5a87',
          600: '#26426b',
          700: '#1d3355',
          800: '#162741', // primário da marca
          900: '#101c30'
        },
        brick: {
          50: '#fdecec',
          100: '#f9cdd0',
          200: '#f0a1a6',
          300: '#e5747c',
          400: '#d4444f',
          500: '#b8202c', // vermelho da marca (AGORA)
          600: '#9c1a25',
          700: '#7d151d',
          800: '#5f1016',
          900: '#420b0f'
        },
        sand: '#f6f5f2'
      },
      fontFamily: {
        display: ['"Sora"', 'sans-serif'],
        body: ['"Inter"', 'sans-serif']
      },
      boxShadow: {
        card: '0 2px 10px -2px rgba(22, 39, 65, 0.12), 0 8px 24px -8px rgba(22, 39, 65, 0.08)',
        nav: '0 -2px 16px rgba(22, 39, 65, 0.08)'
      },
      keyframes: {
        fadeIn: { '0%': { opacity: 0 }, '100%': { opacity: 1 } },
        slideUp: { '0%': { opacity: 0, transform: 'translateY(16px)' }, '100%': { opacity: 1, transform: 'translateY(0)' } },
        slideIn: { '0%': { transform: 'translateX(-100%)' }, '100%': { transform: 'translateX(0)' } },
        pulseSlow: { '0%,100%': { opacity: 1 }, '50%': { opacity: .6 } },
        shimmer: { '0%': { backgroundPosition: '-400px 0' }, '100%': { backgroundPosition: '400px 0' } }
      },
      animation: {
        fadeIn: 'fadeIn .4s ease-out both',
        slideUp: 'slideUp .45s cubic-bezier(.22,1,.36,1) both',
        slideIn: 'slideIn .3s ease-out both',
        pulseSlow: 'pulseSlow 2s ease-in-out infinite',
        shimmer: 'shimmer 1.6s linear infinite'
      }
    }
  },
  plugins: []
}
